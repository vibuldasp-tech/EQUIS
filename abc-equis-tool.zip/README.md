# ABC EQUIS Accreditation Workflow Tool

This repository contains the reference implementation of **ABC School’s internal tool**
that orchestrates all tasks, documents and deadlines required by the EQUIS
accreditation cycle.

## Key features
- Stage‑based workflow engine that mirrors the official 10‑stage EQUIS process
- RBAC enforced through Open Policy Agent (OPA) and PostgreSQL Row‑Level Security
- Structured datasheet & deliverable management with immutable version history
- LLM‑powered text suggestion service for gap‑analysis and writing assistance
- API‑first architecture (FastAPI) with a React front‑end (not included in this skeleton)

## Quick start (local)
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r backend/requirements.txt
uvicorn backend.app:app --reload
```

## Repository structure
```
backend/         # FastAPI service
db/              # SQL schema & migrations
stage_templates/ # JSON blueprints for each EQUIS stage
opa/             # Rego policies for RBAC
.github/         # GitHub Actions CI
```

## License
MIT © ABC School
