from fastapi import FastAPI

app = FastAPI(
    title="ABC EQUIS Workflow Tool",
    version="0.1.0",
    description="API service for managing EQUIS accreditation workflows.",
)

@app.get("/health")
async def health():
    """Health‑check endpoint."""
    return {"status": "ok"}
