-- Core tables
CREATE TABLE IF NOT EXISTS users (
    id          SERIAL PRIMARY KEY,
    name        TEXT NOT NULL,
    email       TEXT UNIQUE NOT NULL,
    time_zone   TEXT DEFAULT 'UTC',
    created_at  TIMESTAMP DEFAULT NOW(),
    updated_at  TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS roles (
    id          SERIAL PRIMARY KEY,
    name        TEXT UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS user_roles (
    user_id     INT REFERENCES users(id) ON DELETE CASCADE,
    role_id     INT REFERENCES roles(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, role_id)
);

CREATE TABLE IF NOT EXISTS stages (
    id          INT PRIMARY KEY,            -- 0‑9 per EQUIS
    name        TEXT NOT NULL,
    open_date   DATE,
    due_date    DATE,
    status      TEXT CHECK (status IN ('pending','active','closed')) DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS tasks (
    id          SERIAL PRIMARY KEY,
    stage_id    INT REFERENCES stages(id) ON DELETE CASCADE,
    title       TEXT NOT NULL,
    owner_id    INT REFERENCES users(id),
    due_at      DATE,
    status      TEXT CHECK (status IN ('draft','in_review','approved','closed')) DEFAULT 'draft',
    dependency_id INT REFERENCES tasks(id),
    created_at  TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS deliverables (
    id          SERIAL PRIMARY KEY,
    stage_id    INT REFERENCES stages(id) ON DELETE CASCADE,
    type        TEXT NOT NULL,
    owner_id    INT REFERENCES users(id),
    status      TEXT CHECK (status IN ('draft','ready','locked')) DEFAULT 'draft'
);

CREATE TABLE IF NOT EXISTS versions (
    id              SERIAL PRIMARY KEY,
    deliverable_id  INT REFERENCES deliverables(id) ON DELETE CASCADE,
    v_major         INT,
    v_minor         INT,
    blob_uri        TEXT NOT NULL,
    created_at      TIMESTAMP DEFAULT NOW()
);
